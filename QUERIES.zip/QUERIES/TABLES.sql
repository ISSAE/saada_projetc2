CREATE TABLE `userlist` (
  `userky` int(9) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `firstName` varchar(50) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL,
  `password` varchar(15) DEFAULT NULL,
  `userstatus` char(1) DEFAULT NULL,
  PRIMARY KEY (`userky`)
);

CREATE TABLE `customers` (
  `customerky` int(9) NOT NULL,
  `firstName` varchar(30) DEFAULT NULL,
  `lastName` varchar(30) DEFAULT NULL,
  `phoneNumber` varchar(20) DEFAULT NULL,
  `mobileNumber` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `region` varchar(30) DEFAULT NULL,
  `zone` varchar(30) DEFAULT NULL,
  `userstatus` varchar(20) DEFAULT NULL,
  `modifiedBy` varchar(20) DEFAULT NULL,
  `modDateLong` date DEFAULT NULL,
  PRIMARY KEY (`customerky`)
);

CREATE TABLE `products` (
  `productnum` int(9) DEFAULT NULL,
  `productName` varchar(30) DEFAULT NULL,  
  `annualfees` int(10) DEFAULT NULL,
  `producttype` varchar(1) default null,
  `modifiedBy` varchar(20) DEFAULT NULL,
  `modDateLong` date DEFAULT NULL
);

CREATE TABLE `cards` (
  `cardserno` int(10) not null,
  `cardID` varchar(16) not NULL,
  `embossing_name` varchar(50) default null,
  `issue_date` date default null,
  `expiry_date` date default null,
  `card_status` varchar(1) default null,
  `customerid` int(9) DEFAULT NULL,
  `modifiedBy` varchar(20) DEFAULT NULL,
  `modDateLong` date DEFAULT NULL
);

CREATE TABLE `transactions` (	
  `transactionID` int(10) DEFAULT NULL,
  `cardID` varchar(16) DEFAULT NULL,
  `authorizationID` varchar(6) DEFAULT NULL,
  `trxdate` date DEFAULT NULL,
  `trxamount` int(15) DEFAULT NULL,
  `trxcurrency` varchar(3) DEFAULT NULL,
  `merchantname` varchar(15) DEFAULT NULL,
  `merchantcountry` varchar(15) DEFAULT NULL,
  `postedOn` date DEFAULT NULL
);

