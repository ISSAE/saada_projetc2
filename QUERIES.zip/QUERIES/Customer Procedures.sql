create table CUST_SEQUENCE (
CUSTOMERID_SERNO int(255));
insert into CUST_SEQUENCE (CUSTOMERID_SERNO) values(1);
---DECLARE i INT DEFAULT 3;

--------SAVE CUSTOMER PROCEDURE----------------------------------------------------------------
DROP PROCEDURE IF EXISTS SAVECUSTOMER;
CREATE PROCEDURE `SAVECUSTOMER`( INOUT CUSTOMERID INT,IN FIRST_NAME VARCHAR(30), 
                                IN LAST_NAME VARCHAR(30), 
                                IN PHONE_NUMBER  VARCHAR(20),IN MOBILE_NUMBER VARCHAR(20), 
                                IN CUST_ADDRESS VARCHAR(50), 
                                IN CUST_REGION VARCHAR(30), IN CUST_ZONE VARCHAR(30),
                                IN PCUST_STATUS VARCHAR(20),
                                IN MODIFYBY VARCHAR(20))
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		ROLLBACK;
		SELECT 0;
	END;
  
IF CUSTOMERID = 0 THEN 
	select CUSTOMERID_SERNO into CUSTOMERID from cust_sequence FOR UPDATE;	
  update cust_sequence set customerid_serno = CUSTOMERID + 1;
  commit;
    INSERT INTO customers (customerky,firstName,lastName,	phoneNumber,mobileNumber,address,region,
							 zone,userstatus,modifiedBy,modDateLong)
					VALUES (CUSTOMERID,FIRST_NAME,LAST_NAME, PHONE_NUMBER,
							MOBILE_NUMBER, CUST_ADDRESS, CUST_REGION, CUST_ZONE,
							PCUST_STATUS,MODIFYBY,sysdate());           
ELSE 
    update customers
      set  firstName	= FIRST_NAME,
           lastName		= LAST_NAME,
           phoneNumber	= PHONE_NUMBER,
           mobileNumber	= MOBILE_NUMBER, 
           address		= CUST_ADDRESS,  
           region		= CUST_REGION, 	
           zone 		= CUST_ZONE, 
           userstatus	= ifnull(PCUST_STATUS,userstatus),
           modifiedBy	= MODIFYBY,
           modDateLong	= sysdate()           
	where  customerky   = CUSTOMERID;
END IF;
COMMIT;
END;



---------------DELETE CUSTOMER PROCEDURE-----------------------------------------------------
---------------------------------------------------------------------------------------------
CREATE PROCEDURE `REMOVECUSTOMER`(INOUT CUSTOMERID INT, IN MODIFYBY VARCHAR(30))
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		ROLLBACK;
		SELECT 0;
	END;

 UPDATE CUSTOMERS SET
  userstatus = 'INACTIVE', modifiedBy = MODIFYBY, modDateLong	= sysdate()
 WHERE customerky = CUSTOMERID;	  
COMMIT;
Set CUSTOMERID = 1;
END;


