	insert into userlist (userky,username, firstName, lastName,password,userstatus)
				values   ('1','saada','Saada','Ibrahim','saada123','A'); 
						  
	insert into userlist (userky,username, firstName, lastName,password,userstatus)
				values   ('2','pascal','Pascal','Fares','P@scal123','A');	


-----------------------customers table
insert into customers (customerky,firstName,lastName,phoneNumber,mobileNumber,address,region,
					   zone,userstatus,modifiedBy,modDateLong)
			values    (1,'Ziad','Diab','05897452','03526857','Beirut','Adlieh','A','ACTIVE','saada',sysdate());
			
insert into customers (customerky,firstName,lastName,phoneNumber,mobileNumber,address,region,
					   zone,userstatus,modifiedBy,modDateLong)
			values    (2,'Wadih','Ibrahim','05458745','03258147','Beirut','Adlieh','A','ACTIVE','saada',sysdate());			

insert into customers (customerky,firstName,lastName,phoneNumber,mobileNumber,address,region,
					   zone,userstatus,modifiedBy,modDateLong)
			values    (3,'Ashure','Ziadeh','01447669','03557981','Beirut','Baabda','A','ACTIVE','saada',sysdate());			
			
insert into customers (customerky,firstName,lastName,phoneNumber,mobileNumber,address,region,
					   zone,userstatus,modifiedBy,modDateLong)
			values    (4,'Anthony','Merhej','09554885','03265356','Jbeil','Mar gerges','A','ACTIVE','saada',sysdate());			
			
insert into customers (customerky,firstName,lastName,phoneNumber,mobileNumber,address,region,
					   zone,userstatus,modifiedBy,modDateLong)
			values    (5,'Nabil','Khoury','09774112','03522882','Nahr Ibrahim','Nahr Ibrahim','A','ACTIVE','saada',sysdate());			
			
insert into customers (customerky,firstName,lastName,phoneNumber,mobileNumber,address,region,
					   zone,userstatus,modifiedBy,modDateLong)
			values    (6,'Ghada','Khoury',null,'03246253','Zahleh','Zahleh','A','ACTIVE','pascal',sysdate());			
			
insert into customers (customerky,firstName,lastName,phoneNumber,mobileNumber,address,region,
					   zone,userstatus,modifiedBy,modDateLong)
			values    (7,'Tony','Ibrahim',null,'72114558','Tyr','Tyr','A','ACTIVE','pascal',sysdate());

insert into customers (customerky,firstName,lastName,phoneNumber,mobileNumber,address,region,
					   zone,userstatus,modifiedBy,modDateLong)
			values    (8,'Maria','Ibrahim','01445554','03225447','Beirut','Achrafieh','A','ACTIVE','pascal',sysdate());

insert into customers (customerky,firstName,lastName,phoneNumber,mobileNumber,address,region,
					   zone,userstatus,modifiedBy,modDateLong)
			values    (9,'Angelo','Mousallem','06258884','70585562','Tripoli','Tripoli','A','ACTIVE','pascal',sysdate());

insert into customers (customerky,firstName,lastName,phoneNumber,mobileNumber,address,region,
					   zone,userstatus,modifiedBy,modDateLong)
			values    (10,'Najib','Mousallem','05889665','03224558','Beirut','Jamhour','A','ACTIVE','pascal',sysdate());

-------------------products
insert into products (productnum,productName,annualfees,producttype,modifiedBy,modDateLong)
            values   (428774,'VISA CREDIT',150,'C','saada',sysdate());

insert into products (productnum,productName,annualfees,producttype,modifiedBy,modDateLong)
            values   (589456,'MC CREDIT',75,'C','pascal',sysdate());
			
insert into products (productnum,productName,annualfees,producttype,modifiedBy,modDateLong)
            values   (489552,'VISA DEBIT',10,'D','saada',sysdate());

-----------------------cards
insert into cards (cardserno,cardID,embossing_name,issue_date,expiry_date,card_status,customerid,
                   modifiedBy,modDateLong )
            values(1,'4287742258964857','NAJIB MOUSALLEM',sysdate(),
			        date_add(sysdate(), interval 1 year),'A',10,'saada',sysdate());


insert into cards (cardserno,cardID,embossing_name,issue_date,expiry_date,card_status,customerid,
                   modifiedBy,modDateLong )
            values(2,'4287742274125896','ANGELO MOUSALLEM',sysdate(),
			       date_add(sysdate(), interval 1 year),'A',9,'saada',sysdate());

insert into cards (cardserno,cardID,embossing_name,issue_date,expiry_date,card_status,customerid,
                   modifiedBy,modDateLong )
            values(3,'4895522254125896','TONY IBRAHIM',sysdate(),
			       date_add(sysdate(), interval 1 year),'A',7,'saada',sysdate());
			
insert into cards (cardserno,cardID,embossing_name,issue_date,expiry_date,card_status,customerid,
                   modifiedBy,modDateLong )
            values(4,'5894562254125436','WADIH IBRAHIM',sysdate(),
			       date_add(sysdate(), interval 1 year),'A',2,'saada',sysdate());
	
-----------------------------transactions

insert into transactions (transactionID,cardID,authorizationID,trxdate,trxamount,trxcurrency,merchantname,
                          merchantcountry, postedOn)
                  values (1,4287742258964857,'33322A',sysdate(),100,'USD','ABC DBAYEH','LEBANON',sysdate());

insert into transactions (transactionID,cardID,authorizationID,trxdate,trxamount,trxcurrency,merchantname,
                          merchantcountry, postedOn)
                  values (2,4287742258964857,'33322B',sysdate(),200,'USD','ABC D','LEBANON',sysdate());

insert into transactions (transactionID,cardID,authorizationID,trxdate,trxamount,trxcurrency,merchantname,
                          merchantcountry, postedOn)
                  values (3,4287742274125896,'C3322B',sysdate(),15000,'LBP','T SHOP','LEBANON',sysdate());
				  
insert into transactions (transactionID,cardID,authorizationID,trxdate,trxamount,trxcurrency,merchantname,
                          merchantcountry, postedOn)
                  values (4,4287742274125896,'C3322Z',sysdate(),15000,'LBP','T SHOP','LEBANON',sysdate());

insert into transactions (transactionID,cardID,authorizationID,trxdate,trxamount,trxcurrency,merchantname,
                          merchantcountry, postedOn)
                  values (5,4287742258964857,'36622A',sysdate(),25,'USD','PARFOIS','LEBANON',sysdate());

insert into transactions (transactionID,cardID,authorizationID,trxdate,trxamount,trxcurrency,merchantname,
                          merchantcountry, postedOn)
                  values (6,4895522254125896,'37892B',sysdate(),59,'USD','TON SHOP','LEBANON',sysdate());

insert into transactions (transactionID,cardID,authorizationID,trxdate,trxamount,trxcurrency,merchantname,
                          merchantcountry, postedOn)
                  values (7,4895522254125896,'D4322B',sysdate(),58000,'LBP','B C','LEBANON',sysdate());
insert into transactions (transactionID,cardID,authorizationID,trxdate,trxamount,trxcurrency,merchantname,
                          merchantcountry, postedOn)
                  values (8,5894562254125436,'12322B',sysdate(),32500,'LBP','TC MAGAZIN','LEBANON',sysdate());
