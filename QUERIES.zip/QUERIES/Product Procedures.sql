DROP PROCEDURE IF EXISTS cnamdb.SAVEPRODUCT;
CREATE PROCEDURE cnamdb.`SAVEPRODUCT`( INOUT prodnum INT,IN PRODUCT_ID INT,IN PRODUCT_NAME VARCHAR(30), 
                                IN annual_fees INT, 
                                IN product_type VARCHAR(1),                                 
                                IN MODIFYBY VARCHAR(20))
BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		ROLLBACK;
		SELECT 0;
	END;
 
 
	select count(*) into prodnum from products where productID = PRODUCT_ID ;
  
 if prodnum = 0 then
    INSERT INTO PRODUCTS(productnum, productName, annualfees, producttype, 
                         modifiedBy, modDateLong)
					VALUES (PRODUCT_ID,PRODUCT_NAME,annual_fees, 
							product_type, MODIFYBY, sysdate()); 
ELSE 
    update products
      set  productnum	  = PRODUCT_ID ,
           productName  = PRODUCT_NAME,
           annualfees	= annual_fees,
           producttype   = product_type,   
           modifiedBy	  = MODIFYBY,
           modDateLong	= sysdate()
	where  productID = PRODUCT_ID;
END IF;
select 1 into prodnum;
commit;
END;
